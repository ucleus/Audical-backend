# Laravel Backend Deployment Guide

## Current Issue: 403 Forbidden Error

The 403 error occurs because the web server is pointing to `/yard/` instead of `/yard/public/`.

## Fix Steps

### 1. Configure Document Root (cPanel/Hosting)

**Option A: Using cPanel**
1. Log into cPanel
2. Go to "Domains" or "Addon Domains"
3. Find the domain/subdirectory settings for `/yard/`
4. Change the **Document Root** from `/yard/` to `/yard/public/`
5. Save changes

**Option B: Using .htaccess in parent directory**
If you can't change the document root, create this file at `/yard/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
```

### 2. Set Correct File Permissions

SSH into your server and run:

```bash
cd /path/to/yard

# Set directory permissions
find . -type d -exec chmod 755 {} \;

# Set file permissions
find . -type f -exec chmod 644 {} \;

# Make Laravel writable directories
chmod -R 775 storage bootstrap/cache

# Set ownership (replace 'username' with your hosting username)
chown -R username:username .
```

### 3. Upload Production Environment File

1. Rename `.env.production` to `.env` on the server
2. Or copy the contents of `.env.production` to your server's `.env` file
3. **Important changes in production .env:**
   - `APP_ENV=production` (was: local)
   - `APP_DEBUG=false` (was: true)
   - `APP_URL=https://audicalservices.com/yard` (was: localhost)
   - `FRONTEND_URL=https://audicalservices.com`
   - `SESSION_PATH=/yard`
   - `SESSION_DOMAIN=audicalservices.com`
   - `LOG_LEVEL=error` (was: debug)

### 4. Run Setup Commands (via SSH)

```bash
cd /path/to/yard

# Install dependencies (if not already done)
composer install --optimize-autoloader --no-dev

# Clear and cache config
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Cache for production
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Run database migrations
php artisan migrate --force

# Create storage link (if using public storage)
php artisan storage:link
```

### 5. Verify Required Directories

Ensure these directories exist with proper permissions:

```bash
mkdir -p storage/framework/cache
mkdir -p storage/framework/sessions
mkdir -p storage/framework/views
mkdir -p storage/logs
mkdir -p bootstrap/cache

chmod -R 775 storage bootstrap/cache
```

### 6. Check Database Connection

The database credentials in `.env.production` are already set:
- **Database:** u652263477_Worriorsground
- **Username:** u652263477_datboi
- **Password:** ~s/:jmP1

Test the connection:
```bash
php artisan migrate:status
```

### 7. Test API Endpoints

Once fixed, test these URLs:

- **Health check:** https://audicalservices.com/yard/api/health
- **Products:** https://audicalservices.com/yard/api/v1/skus
- **Login:** https://audicalservices.com/yard/api/v1/auth/login

## Common Issues & Solutions

### Issue: Still getting 403
- **Check:** Document root points to `/yard/public/`
- **Check:** File permissions are correct (755 for dirs, 644 for files)
- **Check:** `.htaccess` file exists in `/yard/public/`

### Issue: 500 Internal Server Error
- **Check:** `.env` file exists and has correct values
- **Check:** `storage/` and `bootstrap/cache/` are writable (775)
- **Check:** Run `php artisan config:clear` and `php artisan cache:clear`
- **Check:** Error logs at `storage/logs/laravel.log`

### Issue: Database connection error
- **Check:** Database credentials in `.env` are correct
- **Check:** Database exists in cPanel > MySQL Databases
- **Check:** User has permissions on the database

### Issue: Routes not working (404 for all routes)
- **Check:** `.htaccess` file in `public/` folder
- **Check:** Apache `mod_rewrite` is enabled
- **Check:** `AllowOverride All` is set in Apache config

## Directory Structure on Server

Your server structure should look like:
```
/yard/
├── app/
├── bootstrap/
│   └── cache/ (writable 775)
├── config/
├── database/
├── public/ ← Document root should point here
│   ├── .htaccess
│   └── index.php
├── resources/
├── routes/
├── storage/ (writable 775)
│   ├── app/
│   ├── framework/
│   └── logs/
├── .env (production settings)
├── artisan
└── composer.json
```

## Frontend CORS Configuration

Update your frontend's API calls to use:
```javascript
const API_BASE_URL = 'https://audicalservices.com/yard/api';
```

Also ensure CORS is configured in `config/cors.php` to allow:
```php
'allowed_origins' => ['https://audicalservices.com'],
```

## Quick Checklist

- [ ] Document root points to `/yard/public/`
- [ ] `.env` file has production settings
- [ ] File permissions: 755 (dirs), 644 (files)
- [ ] `storage/` and `bootstrap/cache/` are 775
- [ ] Run `composer install --no-dev`
- [ ] Run `php artisan config:cache`
- [ ] Run `php artisan migrate --force`
- [ ] Test: https://audicalservices.com/yard/
