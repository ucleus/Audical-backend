# New OTP System Documentation

## Overview

The OTP (One-Time Password) system has been completely rebuilt with flexibility and reliability in mind. It now works **without email configuration** and includes multiple delivery methods.

## Key Features

### 1. **Multiple Delivery Modes**
- **`auto`** - Automatically uses 'log' for local, 'email' for production (recommended)
- **`email`** - Attempts to send via email, falls back to logs if email fails
- **`log`** - Writes OTP codes to Laravel logs (perfect for development or when email isn't configured)
- **`none`** - Generates codes but doesn't deliver them (testing only)

### 2. **Admin Override Codes**
Special codes that always work (useful for testing and emergency access):
- **`999999`** - Super admin code
- **`888888`** - Support team code

**Note:** Override codes are disabled in production by default (configurable).

### 3. **Email Failure Handling**
If email delivery fails, the system automatically falls back to logging the code instead of throwing an error.

### 4. **Environment-Specific Behavior**
- **Local:** Uses fixed code `000000` by default
- **Production:** Generates random 6-digit codes

## Configuration

### Environment Variables (`.env`)

```env
# OTP Code Settings
OTP_CODE_EXPIRY=5                      # Minutes until code expires
OTP_RATE_LIMIT_PER_HOUR=5              # Max OTP requests per hour per user
OTP_RESEND_INTERVAL_SECONDS=30         # Seconds between OTP requests

# OTP Delivery Mode
OTP_DELIVERY_MODE=log                  # Options: auto, email, log, none
OTP_USE_FIXED_CODE=false               # Use '000000' in local environment
OTP_ALLOW_OVERRIDE_IN_PRODUCTION=true  # Allow admin override codes in production
```

## Production Setup Guide

### Option 1: Use Log Mode (No Email Required)

**Perfect for when email isn't configured yet.**

1. Update `.env` on production server:
   ```env
   OTP_DELIVERY_MODE=log
   OTP_ALLOW_OVERRIDE_IN_PRODUCTION=true
   ```

2. Clear config cache:
   ```bash
   php artisan config:clear
   php artisan config:cache
   ```

3. Request OTP via API
4. Check logs for the code:
   ```bash
   tail -f storage/logs/laravel.log | grep "OTP Code"
   ```

5. Look for:
   ```
   [2025-12-07 23:00:00] local.INFO: 🔐 OTP Code (LOG MODE)
   {"identity":"user@example.com","code":"123456","expires_at":"2025-12-07 23:05:00"}
   ```

### Option 2: Use Override Codes (Easiest)

**No configuration needed!**

1. Enable in `.env`:
   ```env
   OTP_ALLOW_OVERRIDE_IN_PRODUCTION=true
   ```

2. Use these codes anytime:
   - `999999` - Super admin code
   - `888888` - Support team code

3. These codes always work, no matter what email you use!

### Option 3: Configure Email (Most Secure)

Once you have email working:

1. Update `.env`:
   ```env
   OTP_DELIVERY_MODE=email
   MAIL_MAILER=smtp
   MAIL_HOST=smtp.hostinger.com
   MAIL_PORT=587
   MAIL_USERNAME=hi@seanblake.info
   MAIL_PASSWORD=your_password_here
   MAIL_ENCRYPTION=tls
   ```

2. Clear cache:
   ```bash
   php artisan config:clear
   php artisan config:cache
   ```

3. The system will attempt email first, fall back to logs if it fails

## Usage Examples

### Request OTP Code

```bash
POST /api/v1/auth/send-otp
Content-Type: application/json

{
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "message": "OTP sent successfully"
}
```

### Verify OTP Code

**Option A: Use the actual code from logs**
```bash
POST /api/v1/auth/verify-otp
Content-Type: application/json

{
  "email": "user@example.com",
  "code": "123456"
}
```

**Option B: Use override code (if enabled)**
```bash
POST /api/v1/auth/verify-otp
Content-Type: application/json

{
  "email": "user@example.com",
  "code": "999999"
}
```

**Success Response:**
```json
{
  "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "User Name"
  }
}
```

## Finding OTP Codes in Logs

### Via SSH
```bash
# Watch logs in real-time
tail -f storage/logs/laravel.log | grep "OTP"

# View last 50 lines
tail -n 50 storage/logs/laravel.log | grep "OTP"

# Search for specific email
grep "user@example.com" storage/logs/laravel.log | grep "OTP"
```

### Via cPanel File Manager
1. Navigate to `/yard/storage/logs/`
2. Open `laravel.log`
3. Search (Ctrl+F) for: `OTP Code`

### Log Format
```
[2025-12-07 23:00:00] production.INFO: 🔐 OTP Code (LOG MODE)
{
  "identity": "user@example.com",
  "code": "123456",
  "expires_at": "2025-12-07 23:05:00",
  "expires_in_minutes": 5
}
```

## Testing

### Test in Local Development

1. Update `.env`:
   ```env
   OTP_DELIVERY_MODE=log
   OTP_USE_FIXED_CODE=true
   ```

2. Run tinker:
   ```bash
   php artisan tinker
   ```

3. Generate OTP:
   ```php
   $otp = app(App\Services\Auth\OtpService::class);
   $otp->generate('test@example.com');
   exit
   ```

4. Check logs for code (will be `000000` in local)

5. Verify OTP:
   ```php
   $otp = app(App\Services\Auth\OtpService::class);
   $result = $otp->verify('test@example.com', '000000');
   dump($result);
   exit
   ```

### Test Override Codes

```bash
php artisan tinker
```

```php
$otp = app(App\Services\Auth\OtpService::class);
$otp->generate('test@example.com');

// Try admin override code
$result = $otp->verify('test@example.com', '999999');
dump($result);
exit
```

## Security Notes

1. **Override codes** should be changed in production if you enable them permanently
2. **Log mode** exposes codes in logs - ensure log files are secure
3. **Production logs** should only be accessible to administrators
4. Consider switching to email mode once SMTP is configured
5. Override codes log usage with IP and user agent for audit trail

## Troubleshooting

### Issue: "No OTP request found"
- **Cause:** No OTP was generated for that email
- **Fix:** Request OTP first via `/api/v1/auth/send-otp`

### Issue: "OTP expired"
- **Cause:** Code is older than 5 minutes (configurable)
- **Fix:** Request a new OTP

### Issue: "Invalid code"
- **Cause:** Wrong code entered
- **Fix:** Check logs for the correct code, or use override code `999999`

### Issue: Email not sending
- **Fix:** System automatically falls back to logs! Check `storage/logs/laravel.log`

### Issue: Can't find code in logs
- **Check:** Make sure `OTP_DELIVERY_MODE=log` in `.env`
- **Check:** Config cache cleared: `php artisan config:clear`
- **Check:** File permissions on `storage/logs/`

## Migration from Old System

The new system is **backward compatible**. No code changes needed in controllers.

To switch:
1. Replace `app/Services/Auth/OtpService.php` ✅ (Done)
2. Update `config/auth.php` ✅ (Done)
3. Add new env variables ✅ (Done)
4. Clear config cache:
   ```bash
   php artisan config:clear
   php artisan config:cache
   ```

## Recommended Production Configuration

```env
# Until email is configured:
OTP_DELIVERY_MODE=log
OTP_ALLOW_OVERRIDE_IN_PRODUCTION=true

# Once email works:
OTP_DELIVERY_MODE=email
OTP_ALLOW_OVERRIDE_IN_PRODUCTION=false
```

This gives you maximum flexibility while maintaining security!
