<?php

namespace App\Filament\Resources\Skus\RelationManagers;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\KeyValue;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class TutorialsRelationManager extends RelationManager
{
    protected static string $relationship = 'tutorials';

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('title')
                    ->required()
                    ->maxLength(255),
                TextInput::make('youtube_id')
                    ->label('YouTube ID')
                    ->required()
                    ->maxLength(32),
                TextInput::make('thumbnail_url')
                    ->url()
                    ->label('Thumbnail URL')
                    ->maxLength(255),
                TagsInput::make('tags')
                    ->placeholder('calibration, setup')
                    ->default([]),
                Toggle::make('is_featured')
                    ->label('Featured')
                    ->default(false),
                TextInput::make('duration_seconds')
                    ->numeric()
                    ->label('Duration (seconds)')
                    ->minValue(0),
                DateTimePicker::make('published_at')
                    ->label('Published at'),
                KeyValue::make('metadata')
                    ->keyLabel('Key')
                    ->valueLabel('Value')
                    ->default([])
                    ->reorderable()
                    ->columnSpanFull()
                    ->helperText('Optional metadata (e.g., language, difficulty).'),
                RichEditor::make('description')
                    ->columnSpanFull()
                    ->toolbarButtons([
                        'bold',
                        'italic',
                        'bulletList',
                        'orderedList',
                        'link',
                        'undo',
                        'redo',
                    ]),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('title')->searchable()->limit(50),
                TextColumn::make('youtube_id')->label('YouTube'),
                TextColumn::make('duration_seconds')
                    ->label('Duration')
                    ->formatStateUsing(fn (?int $state) => $state ? gmdate('i\:s', $state) : '—'),
                IconColumn::make('is_featured')
                    ->label('Featured')
                    ->boolean(),
                TextColumn::make('published_at')
                    ->label('Published')
                    ->dateTime('M j, Y')
                    ->toggleable(),
                TextColumn::make('updated_at')
                    ->since()
                    ->label('Updated'),
            ])
            ->defaultSort('published_at', 'desc');
    }
}
