<?php

namespace App\Filament\Resources\Skus\RelationManagers;

use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class UnitsRelationManager extends RelationManager
{
    protected static string $relationship = 'units';

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('serial_number')
                    ->required()
                    ->unique(ignoreRecord: true)
                    ->maxLength(255),
                Select::make('status')
                    ->required()
                    ->options([
                        'available' => 'Available',
                        'reserved' => 'Reserved',
                        'leased' => 'Leased',
                        'maintenance' => 'Maintenance',
                    ]),
                TextInput::make('condition')
                    ->maxLength(255),
                TextInput::make('location')
                    ->maxLength(255),
                TextInput::make('purchase_cost')
                    ->numeric()
                    ->prefix('$'),
                DateTimePicker::make('received_at')
                    ->label('Received'),
                DateTimePicker::make('last_service_at')
                    ->label('Last service'),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('serial_number')->searchable(),
                TextColumn::make('status')->badge(),
                TextColumn::make('condition')->limit(20)->toggleable(),
                TextColumn::make('location')->limit(20)->toggleable(),
                TextColumn::make('purchase_cost')->money('usd')->toggleable(isToggledHiddenByDefault: true),
                IconColumn::make('current_order_id')
                    ->label('On order')
                    ->boolean(),
                IconColumn::make('current_lease_id')
                    ->label('On lease')
                    ->boolean(),
                TextColumn::make('received_at')
                    ->date()
                    ->label('Received'),
            ])
            ->defaultSort('created_at', 'desc');
    }
}
