<?php

namespace App\Filament\Resources\Skus;

use App\Filament\Resources\Skus\Pages\ManageSkus;
use App\Filament\Resources\Skus\RelationManagers\TutorialsRelationManager;
use App\Filament\Resources\Skus\RelationManagers\UnitsRelationManager;
use App\Models\Sku;
use BackedEnum;
use UnitEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ForceDeleteAction;
use Filament\Actions\ForceDeleteBulkAction;
use Filament\Actions\RestoreAction;
use Filament\Actions\RestoreBulkAction;
use Filament\Forms\Components\KeyValue;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TrashedFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Schemas\Schema;

class SkuResource extends Resource
{
    protected static ?string $model = Sku::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCube;
    protected static string|UnitEnum|null $navigationGroup = 'Catalog';
    protected static ?string $navigationLabel = 'Equipment SKUs';
    protected static ?int $navigationSort = 1;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Product Details')
                    ->columns(2)
                    ->schema([
                        TextInput::make('name')
                            ->required()
                            ->maxLength(255)
                            ->columnSpan(1)
                            ->live(onBlur: true)
                            ->afterStateUpdated(function (callable $set, callable $get, ?string $state): void {
                                if (! filled($get('slug'))) {
                                    $set('slug', str()->slug((string) $state));
                                }
                            }),
                        TextInput::make('slug')
                            ->required()
                            ->maxLength(255)
                            ->unique(ignoreRecord: true)
                            ->columnSpan(1),
                        TextInput::make('short_description')
                            ->maxLength(255)
                            ->columnSpanFull(),
                        RichEditor::make('description')
                            ->columnSpanFull()
                            ->maxLength(10_000)
                            ->toolbarButtons([
                                'bold',
                                'italic',
                                'bulletList',
                                'orderedList',
                                'link',
                                'undo',
                                'redo',
                            ]),
                        TextInput::make('hs_code')
                            ->label('HS Code')
                            ->maxLength(32),
                        TextInput::make('warranty_terms')
                            ->maxLength(255),
                        Toggle::make('is_active')
                            ->label('Active listing')
                            ->default(true),
                    ]),
                Section::make('Specifications & Media')
                    ->collapsed()
                    ->columns(3)
                    ->schema([
                        KeyValue::make('specs')
                            ->columnSpan(1)
                            ->keyLabel('Spec')
                            ->valueLabel('Value')
                            ->addButtonLabel('Add spec')
                            ->reorderable()
                            ->helperText('Technical specifications shown on the PDP.')
                            ->default([]),
                        KeyValue::make('features')
                            ->columnSpan(1)
                            ->keyLabel('Feature')
                            ->valueLabel('Detail')
                            ->addButtonLabel('Add feature')
                            ->reorderable()
                            ->default([]),
                        TagsInput::make('media')
                            ->columnSpan(1)
                            ->placeholder('https://example.com/image.jpg')
                            ->helperText('Add URLs for product media.')
                            ->default([]),
                    ]),
                Section::make('Pricing & Inventory')
                    ->collapsed()
                    ->columns(3)
                    ->schema([
                        TextInput::make('price_sale')
                            ->label('Sale price (USD)')
                            ->numeric()
                            ->prefix('$')
                            ->minValue(0)
                            ->maxValue(999999.99)
                            ->rule('decimal:0,2')
                            ->columnSpan(1),
                        TextInput::make('stock_on_hand')
                            ->numeric()
                            ->minValue(0)
                            ->default(0)
                            ->rule('integer')
                            ->columnSpan(1),
                        TextInput::make('stock_reserved')
                            ->numeric()
                            ->minValue(0)
                            ->default(0)
                            ->rule('integer')
                            ->helperText('Units held for pending orders or leases.')
                            ->columnSpan(1),
                        TextInput::make('lease_price_12')
                            ->label('12 mo lease (USD)')
                            ->numeric()
                            ->prefix('$')
                            ->minValue(0)
                            ->maxValue(999999.99)
                            ->rule('decimal:0,2')
                            ->columnSpan(1),
                        TextInput::make('lease_price_24')
                            ->label('24 mo lease (USD)')
                            ->numeric()
                            ->prefix('$')
                            ->minValue(0)
                            ->maxValue(999999.99)
                            ->rule('decimal:0,2')
                            ->columnSpan(1),
                        TextInput::make('lease_price_36')
                            ->label('36 mo lease (USD)')
                            ->numeric()
                            ->prefix('$')
                            ->minValue(0)
                            ->maxValue(999999.99)
                            ->rule('decimal:0,2')
                            ->columnSpan(1),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->searchable()
                    ->sortable()
                    ->limit(40),
                TextColumn::make('slug')
                    ->toggleable(isToggledHiddenByDefault: true)
                    ->copyable(),
                TextColumn::make('price_sale')
                    ->label('Sale')
                    ->money('usd')
                    ->sortable()
                    ->toggleable(),
                TextColumn::make('lease_price_12')
                    ->label('Lease 12')
                    ->money('usd')
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('stock_on_hand')
                    ->label('Available stock')
                    ->sortable(),
                TextColumn::make('units_count')
                    ->counts('units')
                    ->label('Units total')
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('tutorials_count')
                    ->counts('tutorials')
                    ->label('Tutorials')
                    ->toggleable(isToggledHiddenByDefault: true),
                IconColumn::make('is_active')
                    ->boolean()
                    ->label('Active'),
                TextColumn::make('updated_at')
                    ->dateTime('M j, Y')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('name')
            ->filters([
                SelectFilter::make('is_active')
                    ->options([
                        '1' => 'Active',
                        '0' => 'Inactive',
                    ])
                    ->label('Listing status'),
                TrashedFilter::make(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
                ForceDeleteAction::make(),
                RestoreAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                    ForceDeleteBulkAction::make(),
                    RestoreBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageSkus::route('/'),
        ];
    }

    public static function getRelations(): array
    {
        return [
            TutorialsRelationManager::class,
            UnitsRelationManager::class,
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        return (string) static::getModel()::query()->count();
    }

    public static function getGloballySearchableAttributes(): array
    {
        return [
            'name',
            'slug',
            'short_description',
        ];
    }

    public static function getRecordRouteBindingEloquentQuery(): Builder
    {
        return parent::getRecordRouteBindingEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ]);
    }
}
