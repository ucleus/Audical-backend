<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\LeaseResource;
use App\Http\Resources\OrderResource;
use App\Http\Resources\UserResource;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class AccountController extends Controller
{
    public function profile(Request $request): UserResource
    {
        $user = $request->user();
        $user->load(['facility', 'facilities']);

        return new UserResource($user);
    }

    public function orders(Request $request): AnonymousResourceCollection
    {
        $user = $request->user();

        $orders = $user->orders()
            ->with(['items.sku', 'shipments'])
            ->latest('placed_at')
            ->paginate((int) $request->integer('per_page', 10))
            ->appends($request->query());

        return OrderResource::collection($orders);
    }

    public function leases(Request $request): AnonymousResourceCollection
    {
        $user = $request->user();

        $facility = $user->facility;

        if (! $facility) {
            return LeaseResource::collection(collect());
        }

        $leases = $facility->leases()
            ->with(['sku', 'unit'])
            ->latest('starts_at')
            ->paginate((int) $request->integer('per_page', 10))
            ->appends($request->query());

        return LeaseResource::collection($leases);
    }
}
