<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lease;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Shipment;
use App\Models\Verification;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Carbon;

class AnalyticsController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $gmv = (int) Order::query()
            ->whereNotIn('status', ['canceled', 'draft'])
            ->sum('grand_total');

        $unitsSold = (int) OrderItem::query()->sum('quantity');

        $unitsLeased = (int) Lease::query()
            ->whereIn('status', ['active', 'provisioning', 'pending'])
            ->count();

        $totalShipments = (int) Shipment::query()->count();
        $onTimeShipments = (int) Shipment::query()
            ->whereNotNull('delivered_at')
            ->count();
        $onTimeShipRate = $totalShipments > 0 ? round($onTimeShipments / $totalShipments, 4) : 0.0;

        $approvalLeadDays = Verification::query()
            ->where('status', 'approved')
            ->whereNotNull('submitted_at')
            ->whereNotNull('reviewed_at')
            ->get()
            ->map(fn (Verification $verification): float => Carbon::parse($verification->submitted_at)->diffInHours($verification->reviewed_at) / 24)
            ->avg() ?? 0.0;

        return response()->json([
            'gmv' => $gmv,
            'units_sold' => $unitsSold,
            'units_leased' => $unitsLeased,
            'on_time_ship_rate' => $onTimeShipRate,
            'avg_approval_lead_days' => round($approvalLeadDays, 2),
        ]);
    }
}
