<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\JWTAuth;

class RefreshTokenController extends Controller
{
    public function __invoke(Request $request, JWTAuth $jwt): JsonResponse
    {
        $token = $request->bearerToken();

        if (! $token) {
            return response()->json(['message' => 'Refresh token missing.'], 401);
        }

        try {
            $jwt->setToken($token);

            if ($jwt->getClaim('token_type') !== 'refresh') {
                return response()->json(['message' => 'Invalid token type.'], 401);
            }

            $user = $jwt->authenticate();
            $auth = auth('api');
            $factory = $auth->factory();
            $originalTtl = $factory->getTTL();

            $accessToken = $auth->setTTL(config('jwt.ttl'))->login($user);
            $accessExpiresIn = $factory->getTTL() * 60;

            $auth->setTTL($originalTtl);

            return response()->json([
                'access_token' => $accessToken,
                'token_type' => 'Bearer',
                'expires_in' => $accessExpiresIn,
            ]);
        } catch (JWTException $exception) {
            return response()->json([
                'message' => $exception->getMessage(),
            ], 401);
        }
    }
}
