<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RequestOtpRequest;
use App\Models\User;
use App\Services\Auth\OtpService;
use Illuminate\Http\JsonResponse;

class RequestOtpController extends Controller
{
    public function __invoke(RequestOtpRequest $request, OtpService $otpService): JsonResponse
    {
        $payload = $request->validated();

        $channel = $payload['channel'] ?? 'email';

        if ($channel === 'sms') {
            $exists = User::query()->where('phone', $payload['identity'])->exists();

            if (! $exists) {
                return response()->json([
                    'message' => 'Account not found for provided phone number.',
                ], 404);
            }
        }

        $otpService->generate($payload['identity'], $channel);

        return response()->json([
            'message' => 'OTP sent successfully.',
        ]);
    }
}
