<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\VerifyOtpRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\Auth\OtpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

class VerifyOtpController extends Controller
{
    public function __invoke(VerifyOtpRequest $request, OtpService $otpService): JsonResponse
    {
        $payload = $request->validated();

        try {
            $channel = $payload['channel'] ?? 'email';

            $otpService->verify($payload['identity'], $payload['code']);

            /** @var User|null $user */
            $user = null;

            if ($channel === 'sms') {
                $user = User::query()->where('phone', $payload['identity'])->first();

                if (! $user) {
                    return response()->json([
                        'message' => 'Account not found for provided phone number.',
                    ], 404);
                }
            } else {
                $user = User::query()->firstOrCreate(
                    ['email' => strtolower($payload['identity'])],
                    [
                        'status' => 'pending',
                        'role' => 'customer',
                    ]
                );
            }

            if (! $user->email_verified_at) {
                $user->email_verified_at = Carbon::now();
            }

            $user->last_login_at = Carbon::now();
            $user->save();

            $auth = auth('api');
            $factory = $auth->factory();
            $originalTtl = $factory->getTTL();

            $accessToken = $auth->login($user);
            $accessExpiresIn = $factory->getTTL() * 60;

            $refreshTtl = (int) config('jwt.refresh_ttl', 43200);
            $auth->setTTL($refreshTtl);
            $refreshToken = $auth->claims([
                'token_type' => 'refresh',
                'device' => $payload['device_name'] ?? null,
            ])->tokenById($user->getKey());
            $auth->setTTL($originalTtl);
            $auth->claims([]);

            return response()->json([
                'access_token' => $accessToken,
                'token_type' => 'Bearer',
                'expires_in' => $accessExpiresIn,
                'refresh_token' => $refreshToken,
                'refresh_expires_in' => $refreshTtl * 60,
                'user' => new UserResource($user),
            ]);
        } catch (RuntimeException $exception) {
            return response()->json([
                'message' => $exception->getMessage(),
            ], 422);
        } catch (Throwable $throwable) {
            Log::error('OTP verification failed', [
                'error' => $throwable->getMessage(),
            ]);

            return response()->json([
                'message' => 'Unable to verify the OTP at this time.',
            ], 500);
        }
    }
}
