<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\SkuResource;
use App\Models\Sku;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CatalogController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $query = Sku::query()
            ->where('is_active', true)
            ->withCount(['units as units_available_count' => fn ($relation) => $relation->where('status', 'available')]);

        if ($request->boolean('in_stock', false)) {
            $query->where(function ($builder): void {
                $builder->where('stock_on_hand', '>', 0)
                    ->orWhere('units_available_count', '>', 0);
            });
        }

        if ($search = $request->string('q')->trim()->toString()) {
            $query->where(function ($builder) use ($search): void {
                $builder->where('name', 'like', "%{$search}%")
                    ->orWhere('short_description', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            });
        }

        if ($request->filled('sort')) {
            match ($request->string('sort')->toString()) {
                'price_asc' => $query->orderBy('price_sale'),
                'price_desc' => $query->orderByDesc('price_sale'),
                default => $query->orderBy('name'),
            };
        } else {
            $query->orderBy('name');
        }

        $perPage = (int) $request->integer('per_page', 12);

        return SkuResource::collection(
            $query->paginate($perPage)->appends($request->query())
        );
    }

    public function show(string $slug): SkuResource
    {
        $sku = Sku::query()
            ->with(['tutorials' => fn ($relation) => $relation->orderByDesc('published_at')])
            ->where('slug', $slug)
            ->firstOrFail();

        return new SkuResource($sku);
    }
}
