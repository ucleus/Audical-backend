<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreFacilityVerificationRequest;
use App\Http\Resources\FacilityResource;
use App\Models\Document;
use App\Models\Facility;
use App\Models\Verification;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class FacilityVerificationController extends Controller
{
    public function store(StoreFacilityVerificationRequest $request): JsonResponse
    {
        $user = $request->user();
        $data = $request->validated();

        $verification = DB::transaction(function () use ($user, $data) {
            /** @var Facility $facility */
            $facility = Facility::query()->updateOrCreate(
                ['id' => $user->facility_id],
                [
                    'name' => $data['name'],
                    'type' => $data['type'],
                    'npi' => $data['npi'] ?? null,
                    'ein' => $data['ein'] ?? null,
                    'business_license_number' => $data['business_license_number'] ?? null,
                    'email' => $data['email'],
                    'phone' => $data['phone'] ?? null,
                    'website' => $data['website'] ?? null,
                    'address_line1' => $data['address_line1'],
                    'address_line2' => $data['address_line2'] ?? null,
                    'city' => $data['city'],
                    'state_region' => $data['state_region'] ?? null,
                    'postal_code' => $data['postal_code'] ?? null,
                    'country' => $data['country'],
                    'status' => 'pending',
                ]
            );

            $user->facility_id = $facility->id;
            $user->save();

            $facility->users()->syncWithoutDetaching([$user->id => ['role' => 'admin']]);

            $verification = $facility->verifications()->create([
                'submitted_by' => $user->id,
                'status' => 'pending',
                'notes' => $data['notes'] ?? null,
                'documents' => $data['documents'] ?? [],
                'submitted_at' => now(),
            ]);

            foreach ($data['documents'] ?? [] as $document) {
                Document::query()->updateOrCreate(
                    ['id' => $document['id']],
                    [
                        'owner_type' => Facility::class,
                        'owner_id' => $facility->id,
                        'disk' => 'local',
                        'path' => $document['path'],
                        'filename' => basename($document['path']),
                        'mime_type' => $document['type'] ?? null,
                        'is_private' => true,
                    ]
                );
            }

            return $verification->fresh(['facility']);
        });

        return response()->json([
            'message' => 'Verification submitted successfully.',
            'verification' => [
                'id' => $verification->id,
                'status' => $verification->status,
                'submitted_at' => $verification->submitted_at,
            ],
            'facility' => new FacilityResource($verification->facility),
        ]);
    }
}
