<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Log;
use Stripe\Checkout\Session;
use Stripe\StripeClient;
use Throwable;

class StripeController extends Controller
{
    public function __construct(private readonly StripeClient $stripe = new StripeClient(['api_key' => null]))
    {
        $key = config('services.stripe.secret');

        $this->stripe = new StripeClient($key);
    }

    public function createCheckoutSession(Request $request): JsonResponse
    {
        $data = $request->validate([
            'mode' => ['required', 'in:payment,subscription'],
            'success_url' => ['required', 'url'],
            'cancel_url' => ['required', 'url'],
            'customer_email' => ['nullable', 'email:rfc'],
            'line_items' => ['required', 'array', 'min:1'],
            'line_items.*.price' => ['nullable', 'string'],
            'line_items.*.quantity' => ['required', 'integer', 'min:1'],
            'line_items.*.amount' => ['nullable', 'integer'],
            'line_items.*.currency' => ['nullable', 'string', 'size:3'],
            'line_items.*.name' => ['nullable', 'string'],
            'metadata' => ['nullable', 'array'],
        ]);

        $lineItems = collect($data['line_items'])->map(function (array $item): array {
            if (! empty($item['price'])) {
                return [
                    'price' => $item['price'],
                    'quantity' => $item['quantity'],
                ];
            }

            return [
                'price_data' => [
                    'currency' => Arr::get($item, 'currency', 'usd'),
                    'product_data' => [
                        'name' => Arr::get($item, 'name', 'Audical Equipment'),
                    ],
                    'unit_amount' => Arr::get($item, 'amount'),
                ],
                'quantity' => $item['quantity'],
            ];
        })->all();

        try {
            $session = $this->stripe->checkout->sessions->create([
                'mode' => $data['mode'],
                'success_url' => $data['success_url'],
                'cancel_url' => $data['cancel_url'],
                'customer_email' => $data['customer_email'] ?? null,
                'line_items' => $lineItems,
                'metadata' => $data['metadata'] ?? [],
                'locale' => 'auto',
                'billing_address_collection' => 'required',
            ]);

            return response()->json([
                'id' => $session->id,
                'url' => $session->url,
            ]);
        } catch (Throwable $throwable) {
            Log::error('Stripe checkout session error', [
                'message' => $throwable->getMessage(),
            ]);

            return response()->json([
                'message' => 'Unable to create checkout session.',
            ], 500);
        }
    }

    public function createBillingPortalSession(Request $request): JsonResponse
    {
        $data = $request->validate([
            'customer_id' => ['required', 'string'],
            'return_url' => ['required', 'url'],
        ]);

        try {
            $session = $this->stripe->billingPortal->sessions->create([
                'customer' => $data['customer_id'],
                'return_url' => $data['return_url'],
            ]);

            return response()->json([
                'url' => $session->url,
            ]);
        } catch (Throwable $throwable) {
            Log::error('Stripe billing portal session error', [
                'message' => $throwable->getMessage(),
            ]);

            return response()->json([
                'message' => 'Unable to create billing portal session.',
            ], 500);
        }
    }
}
