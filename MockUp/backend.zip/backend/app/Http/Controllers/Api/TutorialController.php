<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\TutorialResource;
use App\Models\Tutorial;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class TutorialController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $query = Tutorial::query()
            ->with('sku:id,name,slug')
            ->orderByDesc('published_at');

        if ($request->filled('sku_id')) {
            $query->where('sku_id', $request->string('sku_id')->toString());
        }

        if ($request->filled('tag')) {
            $tag = $request->string('tag')->toString();
            $query->whereJsonContains('tags', $tag);
        }

        if ($search = $request->string('q')->trim()->toString()) {
            $query->where(function ($builder) use ($search): void {
                $builder->where('title', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $perPage = (int) $request->integer('per_page', 12);

        return TutorialResource::collection(
            $query->paginate($perPage)->appends($request->query())
        );
    }
}
