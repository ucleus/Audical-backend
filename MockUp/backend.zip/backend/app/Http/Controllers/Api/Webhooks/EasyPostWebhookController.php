<?php

namespace App\Http\Controllers\Api\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\WebhookEvent;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Throwable;

class EasyPostWebhookController extends Controller
{
    public function __invoke(Request $request): Response
    {
        try {
            $payload = $request->validate([
                'id' => ['required', 'string'],
                'description' => ['nullable', 'string'],
                'status' => ['nullable', 'string'],
                'result' => ['nullable', 'array'],
            ]);
        } catch (Throwable $throwable) {
            Log::warning('EasyPost webhook validation failed', [
                'error' => $throwable->getMessage(),
            ]);

            return response()->noContent(400);
        }

        $webhookEvent = WebhookEvent::query()->updateOrCreate(
            ['event_id' => $payload['id']],
            [
                'provider' => 'easypost',
                'type' => $payload['description'] ?? null,
                'payload' => $payload,
                'processed_at' => now(),
            ]
        );

        Log::info('EasyPost webhook received', [
            'event_id' => $webhookEvent->event_id,
            'status' => $payload['status'] ?? null,
        ]);

        return response()->noContent();
    }
}
