<?php

namespace App\Http\Controllers\Api\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\WebhookEvent;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Stripe\Event;
use Stripe\Stripe;
use Stripe\Webhook;
use Throwable;

class StripeWebhookController extends Controller
{
    public function __invoke(Request $request): Response
    {
        Stripe::setApiKey(config('services.stripe.secret'));

        $payload = $request->getContent();
        $signature = $request->header('Stripe-Signature', '');
        $secret = config('services.stripe.webhook_secret');

        try {
            $event = $secret
                ? Webhook::constructEvent($payload, $signature, $secret)
                : Event::constructFrom(json_decode($payload, true, flags: JSON_THROW_ON_ERROR));
        } catch (Throwable $throwable) {
            Log::warning('Stripe webhook signature verification failed', [
                'error' => $throwable->getMessage(),
            ]);

            return response()->noContent(400);
        }

        $webhookEvent = WebhookEvent::query()->updateOrCreate(
            ['event_id' => $event->id],
            [
                'provider' => 'stripe',
                'type' => $event->type,
                'payload' => $event->toArray(),
                'processed_at' => now(),
            ]
        );

        // Dispatch domain-specific handlers here (orders, subscriptions, etc.).
        // Handlers not implemented in this scaffold; log for visibility.
        Log::info('Stripe webhook processed', [
            'event_id' => $webhookEvent->event_id,
            'type' => $webhookEvent->type,
        ]);

        return response()->noContent();
    }
}
