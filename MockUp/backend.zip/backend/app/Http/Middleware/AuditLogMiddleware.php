<?php

namespace App\Http\Middleware;

use App\Models\AuditLog;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class AuditLogMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $shouldLog = in_array($request->method(), ['POST', 'PUT', 'PATCH', 'DELETE'], true);
        $before = $shouldLog ? $this->redactSensitiveData($request->all()) : [];

        $response = $next($request);

        if (! $shouldLog) {
            return $response;
        }

        $user = $request->user();

        if (! $user) {
            return $response;
        }

        $after = null;

        if ($this->responseIsJson($response)) {
            $decoded = json_decode($response->getContent(), true);
            $after = $this->redactSensitiveData($decoded ?? []);
        }

        AuditLog::create([
            'actor_id' => $user->getKey(),
            'actor_type' => get_class($user),
            'actor_role' => $user->role ?? null,
            'entity_type' => $request->route()?->getName() ?? $request->path(),
            'entity_id' => null,
            'action' => Str::lower($request->method()),
            'before' => $before ?: null,
            'after' => $after,
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 500),
        ]);

        return $response;
    }

    /**
     * @param  array<mixed>  $payload
     * @return array<mixed>
     */
    private function redactSensitiveData(array $payload): array
    {
        $sensitiveKeys = ['password', 'password_confirmation', 'token', 'access_token', 'refresh_token'];

        foreach ($payload as $key => $value) {
            if (in_array($key, $sensitiveKeys, true)) {
                $payload[$key] = '******';
                continue;
            }

            if (is_array($value)) {
                $payload[$key] = $this->redactSensitiveData($value);
            }
        }

        return $payload;
    }

    private function responseIsJson(Response $response): bool
    {
        return Str::contains($response->headers->get('Content-Type', ''), ['application/json', '+json']);
    }
}
