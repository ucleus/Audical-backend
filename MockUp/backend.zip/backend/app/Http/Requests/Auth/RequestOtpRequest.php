<?php

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;

class RequestOtpRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'channel' => $this->input('channel', 'email'),
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'identity' => ['required', 'string', function (string $attribute, string $value, callable $fail) {
                $channel = $this->input('channel', 'email');

                if ($channel === 'sms') {
                    if (! preg_match('/^\+?[0-9]{7,15}$/', $value)) {
                        $fail('Provide a valid phone number including country code.');
                    }

                    return;
                }

                if (! filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $fail('Provide a valid email address.');
                }
            }],
            'channel' => ['sometimes', 'in:email,sms'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'identity.required' => 'Provide an email address to receive your OTP.',
            'identity.email' => 'Use a valid email address.',
        ];
    }
}
