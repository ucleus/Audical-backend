<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FacilityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'type' => $this->type,
            'npi' => $this->npi,
            'ein' => $this->ein,
            'business_license_number' => $this->business_license_number,
            'email' => $this->email,
            'phone' => $this->phone,
            'website' => $this->website,
            'address_line1' => $this->address_line1,
            'address_line2' => $this->address_line2,
            'city' => $this->city,
            'state_region' => $this->state_region,
            'postal_code' => $this->postal_code,
            'country' => $this->country,
            'status' => $this->status,
            'verified_at' => $this->verified_at,
            'denied_at' => $this->denied_at,
            'verification_notes' => $this->verification_notes,
            'metadata' => $this->metadata,
        ];
    }
}
