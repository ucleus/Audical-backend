<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LeaseResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'facility_id' => $this->facility_id,
            'sku_id' => $this->sku_id,
            'unit_id' => $this->unit_id,
            'order_id' => $this->order_id,
            'status' => $this->status,
            'term_months' => $this->term_months,
            'monthly_amount' => $this->monthly_amount,
            'currency' => $this->currency,
            'stripe_subscription_id' => $this->stripe_subscription_id,
            'stripe_customer_id' => $this->stripe_customer_id,
            'stripe_mandate_id' => $this->stripe_mandate_id,
            'starts_at' => $this->starts_at,
            'ends_at' => $this->ends_at,
            'canceled_at' => $this->canceled_at,
            'metadata' => $this->metadata,
            'sku' => $this->whenLoaded('sku', fn () => [
                'id' => $this->sku?->id,
                'name' => $this->sku?->name,
                'slug' => $this->sku?->slug,
            ]),
            'unit' => $this->whenLoaded('unit', fn () => [
                'id' => $this->unit?->id,
                'serial_number' => $this->unit?->serial_number,
                'status' => $this->unit?->status,
            ]),
        ];
    }
}
