<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'number' => $this->number,
            'type' => $this->type,
            'status' => $this->status,
            'currency' => $this->currency,
            'subtotal' => $this->subtotal,
            'tax_total' => $this->tax_total,
            'shipping_total' => $this->shipping_total,
            'grand_total' => $this->grand_total,
            'placed_at' => $this->placed_at,
            'paid_at' => $this->paid_at,
            'fulfilled_at' => $this->fulfilled_at,
            'canceled_at' => $this->canceled_at,
            'billing_address' => $this->billing_address,
            'shipping_address' => $this->shipping_address,
            'stripe_payment_intent_id' => $this->stripe_payment_intent_id,
            'stripe_checkout_session_id' => $this->stripe_checkout_session_id,
            'stripe_invoice_id' => $this->stripe_invoice_id,
            'items' => $this->whenLoaded('items', fn () => $this->items->map(fn ($item) => [
                'id' => $item->id,
                'sku_id' => $item->sku_id,
                'sku_name' => $item->sku?->name,
                'unit_id' => $item->unit_id,
                'quantity' => $item->quantity,
                'unit_price' => $item->unit_price,
                'discount_total' => $item->discount_total,
                'tax_total' => $item->tax_total,
                'line_total' => $item->line_total,
            ])),
            'shipments' => $this->whenLoaded('shipments', fn () => $this->shipments->map(fn ($shipment) => [
                'id' => $shipment->id,
                'carrier' => $shipment->carrier,
                'service' => $shipment->service,
                'tracking_code' => $shipment->tracking_code,
                'status' => $shipment->status,
                'label_url' => $shipment->label_url,
                'delivered_at' => $shipment->delivered_at,
            ])),
        ];
    }
}
