<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SkuResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'slug' => $this->slug,
            'name' => $this->name,
            'short_description' => $this->short_description,
            'description' => $this->description,
            'specs' => $this->specs,
            'features' => $this->features,
            'media' => $this->media,
            'hs_code' => $this->hs_code,
            'warranty_terms' => $this->warranty_terms,
            'price_sale' => $this->price_sale,
            'lease_price_12' => $this->lease_price_12,
            'lease_price_24' => $this->lease_price_24,
            'lease_price_36' => $this->lease_price_36,
            'stock_on_hand' => $this->stock_on_hand,
            'stock_reserved' => $this->stock_reserved,
            'is_active' => $this->is_active,
            'units_available_count' => $this->when(isset($this->units_available_count), $this->units_available_count),
            'tutorials' => TutorialResource::collection($this->whenLoaded('tutorials')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
