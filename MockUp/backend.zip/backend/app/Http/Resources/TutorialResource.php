<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TutorialResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'sku_id' => $this->sku_id,
            'title' => $this->title,
            'youtube_id' => $this->youtube_id,
            'thumbnail_url' => $this->thumbnail_url,
            'description' => $this->description,
            'duration_seconds' => $this->duration_seconds,
            'tags' => $this->tags,
            'is_featured' => $this->is_featured,
            'published_at' => $this->published_at,
            'sku' => $this->whenLoaded('sku', fn () => [
                'id' => $this->sku?->id,
                'name' => $this->sku?->name,
                'slug' => $this->sku?->slug,
            ]),
        ];
    }
}
