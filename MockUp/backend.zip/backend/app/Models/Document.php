<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Document extends Model
{
    use HasFactory;
    use HasUuids;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'owner_type',
        'owner_id',
        'disk',
        'path',
        'filename',
        'mime_type',
        'size',
        'is_private',
        'metadata',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'is_private' => 'boolean',
        'metadata' => 'array',
    ];

    /**
     * Polymorphic owner of the document.
     *
     * @return \Illuminate\Database\Eloquent\Relations\MorphTo<Model, self>
     */
    public function owner(): MorphTo
    {
        return $this->morphTo();
    }
}
