<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Lease extends Model
{
    use HasFactory;
    use HasUuids;
    use SoftDeletes;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'facility_id',
        'sku_id',
        'unit_id',
        'order_id',
        'status',
        'term_months',
        'monthly_amount',
        'currency',
        'stripe_subscription_id',
        'stripe_customer_id',
        'stripe_mandate_id',
        'starts_at',
        'ends_at',
        'canceled_at',
        'metadata',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'monthly_amount' => 'decimal:2',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
        'canceled_at' => 'datetime',
        'metadata' => 'array',
    ];

    /**
     * Facility tied to the lease.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Facility, self>
     */
    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }

    /**
     * SKU being leased.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Sku, self>
     */
    public function sku(): BelongsTo
    {
        return $this->belongsTo(Sku::class);
    }

    /**
     * Physical unit assigned to the lease.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Unit, self>
     */
    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    /**
     * Originating order, if any.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Order, self>
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Warranty records created for the leased unit.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Warranty>
     */
    public function warranties(): HasMany
    {
        return $this->hasMany(Warranty::class);
    }
}
