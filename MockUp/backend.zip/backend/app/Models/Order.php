<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Order extends Model
{
    use HasFactory;
    use HasUuids;
    use SoftDeletes;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'user_id',
        'facility_id',
        'number',
        'type',
        'status',
        'currency',
        'subtotal',
        'tax_total',
        'shipping_total',
        'grand_total',
        'billing_address',
        'shipping_address',
        'metadata',
        'stripe_payment_intent_id',
        'stripe_checkout_session_id',
        'stripe_invoice_id',
        'easypost_shipment_id',
        'placed_at',
        'paid_at',
        'fulfilled_at',
        'canceled_at',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'subtotal' => 'decimal:2',
        'tax_total' => 'decimal:2',
        'shipping_total' => 'decimal:2',
        'grand_total' => 'decimal:2',
        'billing_address' => 'array',
        'shipping_address' => 'array',
        'metadata' => 'array',
        'placed_at' => 'datetime',
        'paid_at' => 'datetime',
        'fulfilled_at' => 'datetime',
        'canceled_at' => 'datetime',
    ];

    /**
     * Automatically assign an order number when creating.
     */
    protected static function booted(): void
    {
        static::creating(function (self $order): void {
            if (! $order->number) {
                $order->number = 'ORD-' . Str::upper(Str::random(8));
            }
        });
    }

    /**
     * Customer who placed the order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<User, self>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Facility associated with the order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Facility, self>
     */
    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }

    /**
     * Line items on the order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<OrderItem>
     */
    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Shipments created for this order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Shipment>
     */
    public function shipments(): HasMany
    {
        return $this->hasMany(Shipment::class);
    }

    /**
     * Warranty claims opened against this order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<WarrantyClaim>
     */
    public function warrantyClaims(): HasMany
    {
        return $this->hasMany(WarrantyClaim::class);
    }
}
