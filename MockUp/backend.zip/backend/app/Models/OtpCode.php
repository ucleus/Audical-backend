<?php

namespace App\Models;

use Carbon\CarbonImmutable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OtpCode extends Model
{
    use HasFactory;

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = true;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'identity',
        'channel',
        'code',
        'code_hash',
        'ip_address',
        'user_agent',
        'attempts',
        'expires_at',
        'consumed_at',
        'metadata',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'expires_at' => 'immutable_datetime',
        'consumed_at' => 'immutable_datetime',
        'metadata' => 'array',
    ];

    /**
     * Determine whether the OTP has expired.
     */
    public function isExpired(): bool
    {
        return optional($this->expires_at)->isPast() ?? true;
    }

    /**
     * Determine whether the OTP has been consumed.
     */
    public function isConsumed(): bool
    {
        return $this->consumed_at !== null;
    }

    /**
     * Mark the OTP as consumed.
     */
    public function markConsumed(): void
    {
        $this->forceFill([
            'consumed_at' => CarbonImmutable::now(),
        ])->save();
    }
}
