<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Shipment extends Model
{
    use HasFactory;
    use HasUuids;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'order_id',
        'carrier',
        'service',
        'tracking_code',
        'status',
        'label_url',
        'easypost_shipment_id',
        'packages',
        'address_from',
        'address_to',
        'label_purchased_at',
        'delivered_at',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'packages' => 'array',
        'address_from' => 'array',
        'address_to' => 'array',
        'label_purchased_at' => 'datetime',
        'delivered_at' => 'datetime',
    ];

    /**
     * Associated order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Order, self>
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }
}
