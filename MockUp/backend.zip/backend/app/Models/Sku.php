<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\SoftDeletes;

class Sku extends Model
{
    use HasFactory;
    use HasUuids;
    use SoftDeletes;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'slug',
        'name',
        'short_description',
        'description',
        'specs',
        'features',
        'media',
        'hs_code',
        'warranty_terms',
        'price_sale',
        'lease_price_12',
        'lease_price_24',
        'lease_price_36',
        'stock_on_hand',
        'stock_reserved',
        'is_active',
        'metadata',
    ];

    /**
     * @var list<string, string>
     */
    protected $casts = [
        'specs' => 'array',
        'features' => 'array',
        'media' => 'array',
        'metadata' => 'array',
        'price_sale' => 'decimal:2',
        'lease_price_12' => 'decimal:2',
        'lease_price_24' => 'decimal:2',
        'lease_price_36' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    /**
     * Physical units attached to the SKU.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Unit>
     */
    public function units(): HasMany
    {
        return $this->hasMany(Unit::class);
    }

    /**
     * Tutorials linked to this SKU.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Tutorial>
     */
    public function tutorials(): HasMany
    {
        return $this->hasMany(Tutorial::class);
    }

    /**
     * Order items referencing this SKU.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<OrderItem>
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Leases that include this SKU.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Lease>
     */
    public function leases(): HasMany
    {
        return $this->hasMany(Lease::class);
    }

    /**
     * Warranties associated with the SKU.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Warranty>
     */
    public function warranties(): HasMany
    {
        return $this->hasMany(Warranty::class);
    }
}
