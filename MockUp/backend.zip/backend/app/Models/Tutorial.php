<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Tutorial extends Model
{
    use HasFactory;
    use HasUuids;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'sku_id',
        'title',
        'youtube_id',
        'thumbnail_url',
        'description',
        'duration_seconds',
        'tags',
        'is_featured',
        'published_at',
        'metadata',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'tags' => 'array',
        'is_featured' => 'boolean',
        'published_at' => 'datetime',
        'metadata' => 'array',
    ];

    /**
     * Owning SKU (optional).
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Sku, self>
     */
    public function sku(): BelongsTo
    {
        return $this->belongsTo(Sku::class);
    }
}
