<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Unit extends Model
{
    use HasFactory;
    use HasUuids;
    use SoftDeletes;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'sku_id',
        'serial_number',
        'status',
        'condition',
        'location',
        'purchase_cost',
        'received_at',
        'current_order_id',
        'current_lease_id',
        'last_service_at',
        'metadata',
    ];

    /**
     * @var list<string, string>
     */
    protected $casts = [
        'purchase_cost' => 'decimal:2',
        'received_at' => 'datetime',
        'last_service_at' => 'datetime',
        'metadata' => 'array',
    ];

    /**
     * Owning SKU.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Sku, self>
     */
    public function sku(): BelongsTo
    {
        return $this->belongsTo(Sku::class);
    }

    /**
     * Order currently holding the unit.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Order, self>
     */
    public function currentOrder(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'current_order_id');
    }

    /**
     * Lease currently holding the unit.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Lease, self>
     */
    public function currentLease(): BelongsTo
    {
        return $this->belongsTo(Lease::class, 'current_lease_id');
    }

    /**
     * Warranty records tied to this unit.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<Warranty>
     */
    public function warranties(): HasMany
    {
        return $this->hasMany(Warranty::class);
    }

    /**
     * Warranty claims submitted for this unit.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<WarrantyClaim>
     */
    public function warrantyClaims(): HasMany
    {
        return $this->hasMany(WarrantyClaim::class);
    }
}
