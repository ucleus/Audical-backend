<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Warranty extends Model
{
    use HasFactory;
    use HasUuids;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'sku_id',
        'unit_id',
        'order_id',
        'lease_id',
        'facility_id',
        'status',
        'starts_at',
        'ends_at',
        'coverage_months',
        'terms',
        'metadata',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
        'metadata' => 'array',
    ];

    /**
     * SKU covered by the warranty.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Sku, self>
     */
    public function sku(): BelongsTo
    {
        return $this->belongsTo(Sku::class);
    }

    /**
     * Unit covered by the warranty.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Unit, self>
     */
    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    /**
     * Owning facility.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Facility, self>
     */
    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }

    /**
     * Originating order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Order, self>
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Lease connected to this warranty.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Lease, self>
     */
    public function lease(): BelongsTo
    {
        return $this->belongsTo(Lease::class);
    }

    /**
     * Claims opened under the warranty.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<WarrantyClaim>
     */
    public function claims(): HasMany
    {
        return $this->hasMany(WarrantyClaim::class);
    }
}
