<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WarrantyClaim extends Model
{
    use HasFactory;
    use HasUuids;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'warranty_id',
        'unit_id',
        'facility_id',
        'order_id',
        'status',
        'ticket_number',
        'issue_description',
        'resolution_notes',
        'opened_at',
        'closed_at',
        'attachments',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'opened_at' => 'datetime',
        'closed_at' => 'datetime',
        'attachments' => 'array',
    ];

    /**
     * Warranty this claim is tied to.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Warranty, self>
     */
    public function warranty(): BelongsTo
    {
        return $this->belongsTo(Warranty::class);
    }

    /**
     * Unit under claim.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Unit, self>
     */
    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    /**
     * Facility submitting the claim.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Facility, self>
     */
    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }

    /**
     * Related order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<Order, self>
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }
}
