<?php

namespace App\Services\Auth;

use App\Mail\Auth\OtpCodeMail;
use App\Models\OtpCode;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class OtpService
{
    /**
     * Admin override codes that always work (useful for testing/emergency access)
     */
    private const OVERRIDE_CODES = [
        '999999', // Super admin code
        '888888', // Support team code
    ];

    public function __construct(private readonly Mailer $mailer)
    {
    }

    /**
     * Generate and dispatch a one-time passcode.
     *
     * Delivery modes:
     * - 'email': Attempt to send via email (falls back to log if fails)
     * - 'log': Only write to logs (dev mode)
     * - 'none': Generate but don't send (return code for testing)
     */
    public function generate(string $identity, string $channel = 'email'): OtpCode
    {
        $this->assertRateLimit($identity, $channel);

        // Determine delivery mode from config or environment
        $deliveryMode = config('auth.otp.delivery_mode', 'auto');

        // Auto mode: use 'log' for local, 'email' for production
        if ($deliveryMode === 'auto') {
            $deliveryMode = app()->environment('local') ? 'log' : 'email';
        }

        // Generate code
        $code = $this->generateCode();

        $expiresAt = CarbonImmutable::now()->addMinutes((int) config('auth.otp.expiry', 5));

        $otp = OtpCode::create([
            'identity' => strtolower($identity),
            'channel' => $channel,
            'code_hash' => Hash::make($code),
            'ip_address' => request()->ip(),
            'user_agent' => (string) request()->userAgent(),
            'expires_at' => $expiresAt,
        ]);

        // Deliver the OTP based on mode
        $this->deliver($identity, $code, $expiresAt, $deliveryMode);

        return $otp;
    }

    /**
     * Validate an OTP submission and return the matching record.
     * Also checks against admin override codes.
     */
    public function verify(string $identity, string $code): OtpCode
    {
        // Check if it's an admin override code
        if ($this->isOverrideCode($code)) {
            Log::warning('🔓 ADMIN OVERRIDE: OTP bypass used', [
                'identity' => $identity,
                'ip' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ]);

            // Create a special OTP record for the override
            return $this->createOverrideOtpRecord($identity);
        }

        $otp = OtpCode::where('identity', strtolower($identity))
            ->orderByDesc('id')
            ->first();

        if (! $otp) {
            throw new RuntimeException('No OTP request found for this identity.');
        }

        if ($otp->isConsumed()) {
            throw new RuntimeException('OTP already used.');
        }

        if ($otp->isExpired()) {
            throw new RuntimeException('OTP expired.');
        }

        if (! Hash::check($code, (string) $otp->code_hash)) {
            $otp->increment('attempts');
            throw new RuntimeException('Invalid code.');
        }

        $otp->markConsumed();

        return $otp;
    }

    /**
     * Generate a 6-digit OTP code
     */
    private function generateCode(): string
    {
        // In local environment, use a fixed code for convenience
        if (app()->environment('local') && config('auth.otp.use_fixed_code', true)) {
            return '000000';
        }

        return (string) random_int(100000, 999999);
    }

    /**
     * Deliver the OTP code via the specified method
     */
    private function deliver(string $identity, string $code, CarbonImmutable $expiresAt, string $mode): void
    {
        switch ($mode) {
            case 'email':
                $this->deliverViaEmail($identity, $code, $expiresAt);
                break;

            case 'log':
                $this->deliverViaLog($identity, $code, $expiresAt);
                break;

            case 'none':
                // Don't deliver, just log that it was generated
                Log::debug('OTP generated but not delivered', [
                    'identity' => $identity,
                    'mode' => 'none',
                ]);
                break;

            default:
                throw new RuntimeException("Unknown OTP delivery mode: {$mode}");
        }
    }

    /**
     * Attempt to send OTP via email, fall back to log on failure
     */
    private function deliverViaEmail(string $identity, string $code, CarbonImmutable $expiresAt): void
    {
        try {
            $this->mailer->to($identity)->send(new OtpCodeMail($code, $expiresAt));

            Log::info('✉️ OTP sent via email', [
                'identity' => $identity,
                'expires_at' => $expiresAt,
            ]);
        } catch (\Exception $e) {
            // Email failed, fall back to logging
            Log::error('❌ OTP email delivery failed, falling back to log', [
                'identity' => $identity,
                'error' => $e->getMessage(),
            ]);

            $this->deliverViaLog($identity, $code, $expiresAt, true);
        }
    }

    /**
     * Deliver OTP by logging it (useful for development)
     */
    private function deliverViaLog(string $identity, string $code, CarbonImmutable $expiresAt, bool $isFallback = false): void
    {
        $message = $isFallback ? '📋 OTP Code (EMAIL FAILED - CHECK LOGS)' : '🔐 OTP Code (LOG MODE)';

        Log::info($message, [
            'identity' => $identity,
            'code' => $code,
            'expires_at' => $expiresAt->toDateTimeString(),
            'expires_in_minutes' => $expiresAt->diffInMinutes(CarbonImmutable::now()),
        ]);
    }

    /**
     * Check if the code is an admin override code
     */
    private function isOverrideCode(string $code): bool
    {
        // Only allow override codes in non-production environments
        if (app()->environment('production') && !config('auth.otp.allow_override_in_production', false)) {
            return false;
        }

        return in_array($code, self::OVERRIDE_CODES, true);
    }

    /**
     * Create a special OTP record for override codes
     */
    private function createOverrideOtpRecord(string $identity): OtpCode
    {
        $otp = OtpCode::create([
            'identity' => strtolower($identity),
            'channel' => 'override',
            'code_hash' => Hash::make('OVERRIDE'),
            'ip_address' => request()->ip(),
            'user_agent' => (string) request()->userAgent(),
            'expires_at' => CarbonImmutable::now()->addMinutes(5),
        ]);

        $otp->markConsumed();

        return $otp;
    }

    private function assertRateLimit(string $identity, string $channel): void
    {
        $rateLimitPerHour = (int) config('auth.otp.rate_limit_per_hour', 5);
        $resendInterval = (int) config('auth.otp.resend_interval', 30);
        $now = CarbonImmutable::now();

        $recentRequests = OtpCode::where('identity', strtolower($identity))
            ->where('channel', $channel)
            ->where('created_at', '>=', $now->subHour())
            ->count();

        if ($recentRequests >= $rateLimitPerHour) {
            throw new RuntimeException('Too many OTP requests. Try again later.');
        }

        $latest = OtpCode::where('identity', strtolower($identity))
            ->where('channel', $channel)
            ->orderByDesc('id')
            ->first();

        if ($latest && $latest->created_at?->diffInSeconds($now) < $resendInterval) {
            throw new RuntimeException('Please wait before requesting another OTP.');
        }
    }
}
