<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('skus', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('slug')->unique();
            $table->string('name');
            $table->string('short_description')->nullable();
            $table->text('description')->nullable();
            $table->json('specs')->nullable();
            $table->json('features')->nullable();
            $table->json('media')->nullable();
            $table->string('hs_code')->nullable();
            $table->string('warranty_terms')->nullable();
            $table->decimal('price_sale', 12, 2)->nullable();
            $table->decimal('lease_price_12', 12, 2)->nullable();
            $table->decimal('lease_price_24', 12, 2)->nullable();
            $table->decimal('lease_price_36', 12, 2)->nullable();
            $table->unsignedInteger('stock_on_hand')->default(0);
            $table->unsignedInteger('stock_reserved')->default(0);
            $table->boolean('is_active')->default(true);
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['is_active']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('skus');
    }
};
