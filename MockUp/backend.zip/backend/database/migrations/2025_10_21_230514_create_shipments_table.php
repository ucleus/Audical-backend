<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('shipments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('order_id');
            $table->string('carrier')->nullable();
            $table->string('service')->nullable();
            $table->string('tracking_code')->nullable();
            $table->string('status')->default('pending'); // pending, purchased, in_transit, delivered, exception, canceled
            $table->string('label_url')->nullable();
            $table->string('easypost_shipment_id')->nullable();
            $table->json('packages')->nullable();
            $table->json('address_from')->nullable();
            $table->json('address_to')->nullable();
            $table->timestamp('label_purchased_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamps();

            $table->index(['order_id']);
            $table->foreign('order_id')->references('id')->on('orders')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('shipments');
    }
};
