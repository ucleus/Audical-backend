<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('warranty_claims', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('warranty_id');
            $table->uuid('unit_id')->nullable();
            $table->uuid('facility_id')->nullable();
            $table->uuid('order_id')->nullable();
            $table->string('status')->default('open'); // open, in_review, approved, denied, completed
            $table->string('ticket_number')->unique();
            $table->text('issue_description')->nullable();
            $table->text('resolution_notes')->nullable();
            $table->timestamp('opened_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->json('attachments')->nullable();
            $table->timestamps();

            $table->index(['status']);
            $table->foreign('warranty_id')->references('id')->on('warranties')->cascadeOnDelete();
            $table->foreign('unit_id')->references('id')->on('units')->nullOnDelete();
            $table->foreign('facility_id')->references('id')->on('facilities')->nullOnDelete();
            $table->foreign('order_id')->references('id')->on('orders')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('warranty_claims');
    }
};
