-- ============================================================
-- Audical Services - Complete Database Schema
-- MySQL Database Schema for E-commerce System
-- ============================================================
-- This schema supports:
-- - Product catalog (SKUs) with pricing and inventory
-- - Customer management with authentication
-- - Order processing and tracking
-- - Shipping and fulfillment
-- - Inventory tracking with serial numbers
-- - Multi-facility support
-- ============================================================

-- Drop tables if they exist (in reverse order of dependencies)
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `shipments`;
DROP TABLE IF EXISTS `units`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `skus`;
DROP TABLE IF EXISTS `facility_user`;
DROP TABLE IF EXISTS `facilities`;
DROP TABLE IF EXISTS `sessions`;
DROP TABLE IF EXISTS `password_reset_tokens`;
DROP TABLE IF EXISTS `users`;

-- ============================================================
-- USERS TABLE (Customers & Authentication)
-- ============================================================
-- Stores customer information and handles login/authentication
-- Supports role-based access (customer, admin, etc.)
-- ============================================================
CREATE TABLE `users` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `name` VARCHAR(255) DEFAULT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `phone` VARCHAR(255) DEFAULT NULL,
  `role` VARCHAR(255) NOT NULL DEFAULT 'customer',
  `status` VARCHAR(255) NOT NULL DEFAULT 'pending',
  `facility_id` CHAR(36) DEFAULT NULL,
  `country` VARCHAR(255) DEFAULT NULL,
  `last_login_at` TIMESTAMP NULL DEFAULT NULL,
  `email_verified_at` TIMESTAMP NULL DEFAULT NULL,
  `password` VARCHAR(255) DEFAULT NULL,
  `remember_token` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  INDEX `idx_users_facility_id` (`facility_id`),
  INDEX `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- PASSWORD RESET TOKENS TABLE
-- ============================================================
-- Stores password reset tokens for user authentication
-- ============================================================
CREATE TABLE `password_reset_tokens` (
  `email` VARCHAR(255) NOT NULL PRIMARY KEY,
  `token` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SESSIONS TABLE
-- ============================================================
-- Stores user session data for authentication
-- ============================================================
CREATE TABLE `sessions` (
  `id` VARCHAR(255) NOT NULL PRIMARY KEY,
  `user_id` CHAR(36) DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `payload` LONGTEXT NOT NULL,
  `last_activity` INT NOT NULL,
  INDEX `idx_sessions_user_id` (`user_id`),
  INDEX `idx_sessions_last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- FACILITIES TABLE
-- ============================================================
-- Stores business/facility information for B2B customers
-- Supports verification workflow and compliance tracking
-- ============================================================
CREATE TABLE `facilities` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `type` VARCHAR(255) DEFAULT NULL COMMENT 'clinic, audiology, hospital, etc.',
  `npi` VARCHAR(255) DEFAULT NULL COMMENT 'National Provider Identifier',
  `ein` VARCHAR(255) DEFAULT NULL COMMENT 'Employer Identification Number',
  `business_license_number` VARCHAR(255) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `phone` VARCHAR(255) DEFAULT NULL,
  `website` VARCHAR(255) DEFAULT NULL,
  `address_line1` VARCHAR(255) NOT NULL,
  `address_line2` VARCHAR(255) DEFAULT NULL,
  `city` VARCHAR(255) NOT NULL,
  `state_region` VARCHAR(255) DEFAULT NULL,
  `postal_code` VARCHAR(255) DEFAULT NULL,
  `country` CHAR(2) NOT NULL DEFAULT 'US',
  `status` VARCHAR(255) NOT NULL DEFAULT 'pending' COMMENT 'pending, approved, denied, restricted',
  `verified_at` TIMESTAMP NULL DEFAULT NULL,
  `denied_at` TIMESTAMP NULL DEFAULT NULL,
  `verified_by` CHAR(36) DEFAULT NULL,
  `verification_notes` TEXT DEFAULT NULL,
  `metadata` JSON DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  INDEX `idx_facilities_country_status` (`country`, `status`),
  FOREIGN KEY (`verified_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- FACILITY_USER PIVOT TABLE
-- ============================================================
-- Many-to-many relationship between users and facilities
-- ============================================================
CREATE TABLE `facility_user` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `facility_id` CHAR(36) NOT NULL,
  `user_id` CHAR(36) NOT NULL,
  `role` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`facility_id`) REFERENCES `facilities`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_facility_user_facility_id` (`facility_id`),
  INDEX `idx_facility_user_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add foreign key for users.facility_id after facilities table is created
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_facility_id`
  FOREIGN KEY (`facility_id`) REFERENCES `facilities`(`id`) ON DELETE SET NULL;

-- ============================================================
-- SKUS TABLE (Products)
-- ============================================================
-- Main product catalog table
-- Stores product information, pricing, and stock levels
-- Supports both purchase and lease pricing models
-- ============================================================
CREATE TABLE `skus` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `short_description` VARCHAR(255) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `specs` JSON DEFAULT NULL COMMENT 'Product specifications',
  `features` JSON DEFAULT NULL COMMENT 'Product features array',
  `media` JSON DEFAULT NULL COMMENT 'Product images and media',
  `hs_code` VARCHAR(255) DEFAULT NULL COMMENT 'Harmonized System code for customs',
  `warranty_terms` VARCHAR(255) DEFAULT NULL,
  `price_sale` DECIMAL(12, 2) DEFAULT NULL COMMENT 'Sale price in cents',
  `lease_price_12` DECIMAL(12, 2) DEFAULT NULL COMMENT '12-month lease price',
  `lease_price_24` DECIMAL(12, 2) DEFAULT NULL COMMENT '24-month lease price',
  `lease_price_36` DECIMAL(12, 2) DEFAULT NULL COMMENT '36-month lease price',
  `stock_on_hand` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Available inventory count',
  `stock_reserved` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Reserved/allocated inventory',
  `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
  `metadata` JSON DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  INDEX `idx_skus_is_active` (`is_active`),
  INDEX `idx_skus_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- UNITS TABLE (Inventory Tracking)
-- ============================================================
-- Tracks individual product units by serial number
-- Enables asset tracking, maintenance history, and lease management
-- ============================================================
CREATE TABLE `units` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `sku_id` CHAR(36) NOT NULL,
  `serial_number` VARCHAR(255) NOT NULL UNIQUE,
  `status` VARCHAR(255) NOT NULL DEFAULT 'available' COMMENT 'available, reserved, leased, maintenance',
  `condition` VARCHAR(255) DEFAULT NULL,
  `location` VARCHAR(255) DEFAULT NULL,
  `purchase_cost` DECIMAL(12, 2) DEFAULT NULL,
  `received_at` TIMESTAMP NULL DEFAULT NULL,
  `current_order_id` CHAR(36) DEFAULT NULL,
  `current_lease_id` CHAR(36) DEFAULT NULL,
  `last_service_at` TIMESTAMP NULL DEFAULT NULL,
  `metadata` JSON DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`sku_id`) REFERENCES `skus`(`id`) ON DELETE CASCADE,
  INDEX `idx_units_status` (`status`),
  INDEX `idx_units_current_order_id` (`current_order_id`),
  INDEX `idx_units_current_lease_id` (`current_lease_id`),
  INDEX `idx_units_sku_id` (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ORDERS TABLE
-- ============================================================
-- Main orders table for tracking customer purchases
-- Supports different order types (sale, service, warranty)
-- Integrates with Stripe for payment processing
-- ============================================================
CREATE TABLE `orders` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `facility_id` CHAR(36) DEFAULT NULL,
  `number` VARCHAR(255) NOT NULL UNIQUE COMMENT 'Human-readable order number',
  `type` VARCHAR(255) NOT NULL DEFAULT 'sale' COMMENT 'sale, service, warranty',
  `status` VARCHAR(255) NOT NULL DEFAULT 'draft' COMMENT 'draft, pending_payment, paid, picking, shipped, delivered, canceled, refunded',
  `currency` CHAR(3) NOT NULL DEFAULT 'USD',
  `subtotal` DECIMAL(12, 2) NOT NULL DEFAULT 0,
  `tax_total` DECIMAL(12, 2) NOT NULL DEFAULT 0,
  `shipping_total` DECIMAL(12, 2) NOT NULL DEFAULT 0,
  `grand_total` DECIMAL(12, 2) NOT NULL DEFAULT 0,
  `billing_address` JSON DEFAULT NULL,
  `shipping_address` JSON DEFAULT NULL,
  `metadata` JSON DEFAULT NULL,
  `stripe_payment_intent_id` VARCHAR(255) DEFAULT NULL,
  `stripe_checkout_session_id` VARCHAR(255) DEFAULT NULL,
  `stripe_invoice_id` VARCHAR(255) DEFAULT NULL,
  `easypost_shipment_id` VARCHAR(255) DEFAULT NULL,
  `placed_at` TIMESTAMP NULL DEFAULT NULL,
  `paid_at` TIMESTAMP NULL DEFAULT NULL,
  `fulfilled_at` TIMESTAMP NULL DEFAULT NULL,
  `canceled_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`facility_id`) REFERENCES `facilities`(`id`) ON DELETE SET NULL,
  INDEX `idx_orders_user_id` (`user_id`),
  INDEX `idx_orders_facility_id` (`facility_id`),
  INDEX `idx_orders_status` (`status`),
  INDEX `idx_orders_number` (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ORDER_ITEMS TABLE
-- ============================================================
-- Line items for each order
-- Links products (SKUs) to orders with pricing and quantity
-- ============================================================
CREATE TABLE `order_items` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `order_id` CHAR(36) NOT NULL,
  `sku_id` CHAR(36) NOT NULL,
  `unit_id` CHAR(36) DEFAULT NULL COMMENT 'Specific unit/serial number if applicable',
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(12, 2) NOT NULL,
  `discount_total` DECIMAL(12, 2) NOT NULL DEFAULT 0,
  `tax_total` DECIMAL(12, 2) NOT NULL DEFAULT 0,
  `line_total` DECIMAL(12, 2) NOT NULL,
  `metadata` JSON DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`sku_id`) REFERENCES `skus`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`unit_id`) REFERENCES `units`(`id`) ON DELETE SET NULL,
  INDEX `idx_order_items_order_id` (`order_id`),
  INDEX `idx_order_items_sku_id` (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SHIPMENTS TABLE
-- ============================================================
-- Tracks shipping information for orders
-- Integrates with EasyPost for label generation and tracking
-- ============================================================
CREATE TABLE `shipments` (
  `id` CHAR(36) NOT NULL PRIMARY KEY,
  `order_id` CHAR(36) NOT NULL,
  `carrier` VARCHAR(255) DEFAULT NULL COMMENT 'USPS, UPS, FedEx, etc.',
  `service` VARCHAR(255) DEFAULT NULL COMMENT 'Priority, Express, Ground, etc.',
  `tracking_code` VARCHAR(255) DEFAULT NULL,
  `status` VARCHAR(255) NOT NULL DEFAULT 'pending' COMMENT 'pending, purchased, in_transit, delivered, exception, canceled',
  `label_url` VARCHAR(255) DEFAULT NULL COMMENT 'URL to shipping label PDF',
  `easypost_shipment_id` VARCHAR(255) DEFAULT NULL,
  `packages` JSON DEFAULT NULL COMMENT 'Package dimensions and weight',
  `address_from` JSON DEFAULT NULL COMMENT 'Sender address',
  `address_to` JSON DEFAULT NULL COMMENT 'Recipient address',
  `label_purchased_at` TIMESTAMP NULL DEFAULT NULL,
  `delivered_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  INDEX `idx_shipments_order_id` (`order_id`),
  INDEX `idx_shipments_tracking_code` (`tracking_code`),
  INDEX `idx_shipments_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SAMPLE DATA (Optional - Remove if not needed)
-- ============================================================

-- Sample facility
INSERT INTO `facilities` (`id`, `name`, `type`, `address_line1`, `city`, `state_region`, `postal_code`, `country`, `status`, `created_at`, `updated_at`)
VALUES
  (UUID(), 'Sample Audiology Clinic', 'audiology', '123 Main Street', 'San Francisco', 'CA', '94102', 'US', 'approved', NOW(), NOW());

-- Sample user (customer)
INSERT INTO `users` (`id`, `name`, `email`, `role`, `status`, `country`, `created_at`, `updated_at`)
VALUES
  (UUID(), 'John Doe', 'john.doe@example.com', 'customer', 'active', 'US', NOW(), NOW());

-- Sample products
INSERT INTO `skus` (`id`, `slug`, `name`, `short_description`, `description`, `price_sale`, `lease_price_12`, `stock_on_hand`, `is_active`, `created_at`, `updated_at`)
VALUES
  (UUID(), 'audiometer-pro-2024', 'Audiometer Pro 2024', 'Professional diagnostic audiometer', 'High-precision audiometer with advanced features for comprehensive hearing assessments', 299900, 29900, 5, TRUE, NOW(), NOW()),
  (UUID(), 'tympanometer-advanced', 'Tympanometer Advanced', 'Clinical tympanometry system', 'State-of-the-art tympanometer for middle ear analysis', 199900, 19900, 3, TRUE, NOW(), NOW()),
  (UUID(), 'otoscope-digital', 'Digital Otoscope', 'High-resolution digital otoscope', 'Digital otoscope with HD camera and LED illumination', 89900, 8900, 10, TRUE, NOW(), NOW());

-- ============================================================
-- USEFUL QUERIES FOR REFERENCE
-- ============================================================

-- Get all products with available stock
-- SELECT * FROM skus WHERE is_active = TRUE AND stock_on_hand > 0;

-- Get customer orders with totals
-- SELECT o.number, o.status, o.grand_total, u.name, u.email
-- FROM orders o
-- JOIN users u ON o.user_id = u.id
-- WHERE o.status != 'draft';

-- Get order details with line items
-- SELECT o.number, s.name, oi.quantity, oi.unit_price, oi.line_total
-- FROM orders o
-- JOIN order_items oi ON o.id = oi.order_id
-- JOIN skus s ON oi.sku_id = s.id
-- WHERE o.number = 'ORDER-123';

-- Check inventory levels
-- SELECT
--   s.name,
--   s.stock_on_hand,
--   s.stock_reserved,
--   (s.stock_on_hand - s.stock_reserved) as available_stock,
--   COUNT(u.id) as tracked_units
-- FROM skus s
-- LEFT JOIN units u ON s.id = u.sku_id AND u.status = 'available'
-- GROUP BY s.id;

-- Track shipment status
-- SELECT o.number, sh.tracking_code, sh.carrier, sh.status, sh.delivered_at
-- FROM orders o
-- JOIN shipments sh ON o.id = sh.order_id
-- WHERE o.user_id = 'USER-UUID';
