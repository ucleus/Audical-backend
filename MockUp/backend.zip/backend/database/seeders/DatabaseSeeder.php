<?php

namespace Database\Seeders;

use App\Models\Facility;
use App\Models\Sku;
use App\Models\Tutorial;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $facility = Facility::create([
            'name' => 'Audical Hearing Clinic',
            'type' => 'audiology_practice',
            'npi' => '1234567890',
            'ein' => '98-7654321',
            'business_license_number' => 'LIC-1001',
            'email' => 'clinic@example.com',
            'phone' => '+1-555-123-4567',
            'website' => 'https://clinic.example.com',
            'address_line1' => '123 Main St',
            'address_line2' => 'Suite 200',
            'city' => 'Austin',
            'state_region' => 'TX',
            'postal_code' => '73301',
            'country' => 'US',
            'status' => 'approved',
            'verified_at' => now(),
        ]);

        $admin = User::factory()->create([
            'name' => 'Audical Admin',
            'email' => 'admin@audical.test',
            'phone' => '+1-555-000-0001',
            'role' => 'admin',
            'status' => 'active',
            'facility_id' => $facility->id,
            'country' => 'US',
        ]);

        $admin->facilities()->syncWithoutDetaching([$facility->id => ['role' => 'admin']]);

        $customer = User::factory()->create([
            'name' => 'Dr. Customer',
            'email' => 'customer@audical.test',
            'phone' => '+1-555-000-0002',
            'role' => 'customer',
            'status' => 'active',
            'facility_id' => $facility->id,
            'country' => 'US',
        ]);

        $customer->facilities()->syncWithoutDetaching([$facility->id => ['role' => 'member']]);

        $sku = Sku::create([
            'slug' => 'audical-pro-kit',
            'name' => 'Audical Pro Diagnostic Kit',
            'short_description' => 'Comprehensive hearing diagnostic equipment bundle.',
            'description' => 'Includes audiometer, tympanometer, and accessories suitable for comprehensive diagnostic workflows.',
            'specs' => [
                'power' => '110-240V',
                'certifications' => ['FDA Class II', 'CE Mark'],
            ],
            'features' => [
                'portable_case' => true,
                'cloud_reporting' => true,
            ],
            'media' => ['https://via.placeholder.com/1200x800'],
            'hs_code' => '901890',
            'warranty_terms' => '12 months manufacturer warranty.',
            'price_sale' => 14999.00,
            'lease_price_12' => 1499.00,
            'lease_price_24' => 829.00,
            'lease_price_36' => 599.00,
            'stock_on_hand' => 10,
            'stock_reserved' => 0,
            'is_active' => true,
        ]);

        Tutorial::create([
            'sku_id' => $sku->id,
            'title' => 'Initial Setup & Calibration',
            'youtube_id' => 'dQw4w9WgXcQ',
            'thumbnail_url' => 'https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg',
            'description' => 'Step-by-step walkthrough covering unboxing, calibration, and safety checks.',
            'duration_seconds' => 600,
            'tags' => ['setup', 'calibration'],
            'is_featured' => true,
            'published_at' => now()->subDays(7),
        ]);
    }
}
