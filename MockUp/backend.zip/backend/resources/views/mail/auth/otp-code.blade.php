<x-mail::message>
# Your sign-in code

Use the one-time passcode below to finish signing in to Audical Services:

<x-mail::panel>
    <span style="font-size: 32px; letter-spacing: 6px; font-weight: 700;">{{ $code }}</span>
</x-mail::panel>

This code expires at {{ $expiresAt->setTimezone(config('app.timezone'))->format('g:i A T') }} (about {{ $expiresAt->diffForHumans(now(), ['parts' => 1, 'syntax' => Carbon\CarbonInterface::DIFF_RELATIVE_TO_NOW]) }}).

If you did not request this code, you can safely ignore this email.

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
