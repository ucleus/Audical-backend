<?php

use App\Http\Controllers\Api\AccountController;
use App\Http\Controllers\Api\Admin\AnalyticsController;
use App\Http\Controllers\Api\Auth\LogoutController;
use App\Http\Controllers\Api\Auth\RequestOtpController;
use App\Http\Controllers\Api\Auth\RefreshTokenController;
use App\Http\Controllers\Api\Auth\VerifyOtpController;
use App\Http\Controllers\Api\CatalogController;
use App\Http\Controllers\Api\FacilityVerificationController;
use App\Http\Controllers\Api\StripeController;
use App\Http\Controllers\Api\TutorialController;
use App\Http\Controllers\Api\Webhooks\EasyPostWebhookController;
use App\Http\Controllers\Api\Webhooks\StripeWebhookController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->middleware('api')->group(function (): void {
    Route::post('/auth/request-otp', RequestOtpController::class)->middleware('throttle:otp');
    Route::post('/auth/verify-otp', VerifyOtpController::class);
    Route::post('/auth/refresh-token', RefreshTokenController::class);

    Route::get('/products', [CatalogController::class, 'index']);
    Route::get('/products/{slug}', [CatalogController::class, 'show']);
    Route::get('/tutorials', [TutorialController::class, 'index']);

    Route::middleware('auth:api')->group(function (): void {
        Route::get('/account', [AccountController::class, 'profile']);
        Route::get('/account/orders', [AccountController::class, 'orders']);
        Route::get('/account/leases', [AccountController::class, 'leases']);
        Route::post('/auth/logout', LogoutController::class);

        Route::post('/facility/verification', [FacilityVerificationController::class, 'store']);
        Route::post('/stripe/checkout-session', [StripeController::class, 'createCheckoutSession']);
        Route::post('/stripe/billing-portal', [StripeController::class, 'createBillingPortalSession']);

        Route::prefix('admin')->middleware('ensure.admin')->group(function (): void {
            Route::get('/analytics', AnalyticsController::class);
        });
    });
});

Route::prefix('webhooks')->group(function (): void {
    Route::post('/stripe', StripeWebhookController::class);
    Route::get('/easypost', static fn () => response()->json([
        'message' => 'EasyPost webhook endpoint is online. Send POST requests with event payloads to process them.',
        'supported_methods' => ['POST'],
    ]));
    Route::post('/easypost', EasyPostWebhookController::class);
});
