<?php echo e($slot); ?>

<?php /**PATH /Users/seanb/Documents/Audical-Services/backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>