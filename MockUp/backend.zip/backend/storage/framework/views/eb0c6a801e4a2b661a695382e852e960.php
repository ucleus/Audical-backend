<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Audical Services | Secure OTP Login</title>
    <style>
        :root {
            color-scheme: light dark;
            --bg: #0f162a;
            --bg-panel: #1a233b;
            --bg-input: rgba(255, 255, 255, 0.04);
            --border: rgba(255, 255, 255, 0.12);
            --text: #f2f6ff;
            --text-muted: rgba(242, 246, 255, 0.7);
            --accent: #23c6a6;
            --accent-dark: #18a28b;
            --danger: #f87171;
            --success: #22c55e;
        }

        @media (prefers-color-scheme: light) {
            :root {
                --bg: #f5f7fb;
                --bg-panel: #ffffff;
                --bg-input: rgba(15, 22, 42, 0.04);
                --border: rgba(15, 22, 42, 0.08);
                --text: #101828;
                --text-muted: #475467;
            }
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: radial-gradient(circle at top, rgba(35, 198, 166, 0.12), transparent 55%),
                var(--bg);
            font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            color: var(--text);
            padding: 24px;
        }

        .card {
            width: min(520px, 100%);
            background: var(--bg-panel);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 32px;
            box-shadow: 0 24px 80px rgba(15, 22, 42, 0.35);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 28px;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--accent), #2aa3c3);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: #0b1627;
        }

        h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 700;
        }

        p.lead {
            margin: 12px 0 24px;
            color: var(--text-muted);
            line-height: 1.5;
        }

        label {
            font-weight: 600;
            display: block;
            margin-bottom: 8px;
            color: var(--text);
        }

        input,
        select {
            width: 100%;
            padding: 14px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: var(--bg-input);
            color: var(--text);
            font: inherit;
            transition: border 0.2s ease, box-shadow 0.2s ease;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(35, 198, 166, 0.2);
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
        }

        .row > div {
            flex: 1 1 160px;
        }

        button {
            width: 100%;
            margin-top: 18px;
            padding: 14px 16px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--accent), #2aa3c3);
            color: #0b1627;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }

        button:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 32px rgba(35, 198, 166, 0.28);
        }

        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .secondary-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 12px;
        }

        .secondary-actions button {
            flex: 1 1 160px;
            background: transparent;
            color: var(--text);
            border: 1px solid var(--border);
        }

        .tagline {
            margin-top: 28px;
            font-size: 0.85rem;
            text-align: center;
            color: var(--text-muted);
        }

        .hidden {
            display: none !important;
        }

        .banner {
            border-radius: 12px;
            padding: 16px;
            border: 1px solid rgba(35, 198, 166, 0.25);
            background: rgba(35, 198, 166, 0.08);
            color: var(--text);
            margin-bottom: 12px;
            font-size: 0.95rem;
        }

        .banner strong {
            color: var(--accent);
        }

        .alert {
            border-radius: 12px;
            padding: 14px 16px;
            margin-bottom: 12px;
            font-size: 0.95rem;
            display: flex;
            gap: 12px;
            align-items: flex-start;
        }

        .alert.error {
            background: rgba(248, 113, 113, 0.12);
            border: 1px solid rgba(248, 113, 113, 0.4);
            color: #fecaca;
        }

        .alert.success {
            background: rgba(34, 197, 94, 0.12);
            border: 1px solid rgba(34, 197, 94, 0.35);
            color: #bbf7d0;
        }

        @media (prefers-color-scheme: light) {
            .alert.success {
                color: #166534;
            }

            .alert.error {
                color: #991b1b;
            }

            .banner {
                color: #134e48;
            }
        }

        @media (max-width: 600px) {
            .card {
                padding: 24px 20px;
            }
        }
    </style>
</head>
<body>
    <main class="card" role="main">
        <header class="logo" aria-label="Audical Services">
            <div class="logo-icon" aria-hidden="true">A</div>
            <div>
                <h1>Audical Services</h1>
                <p class="lead">Secure OTP login for clinic staff and partners.</p>
            </div>
        </header>

        <section id="messages"></section>

        <form id="request-form" autocomplete="off" aria-describedby="request-help">
            <label for="identity">Email or phone number</label>
            <input id="identity" name="identity" type="text" placeholder="you@clinic.com" required autofocus>

            <div class="row">
                <div>
                    <label for="channel">Deliver code via</label>
                    <select id="channel" name="channel">
                        <option value="email" selected>Email</option>
                        <option value="sms">SMS</option>
                    </select>
                </div>
                <div>
                    <label for="device_name">Device label (optional)</label>
                    <input id="device_name" name="device_name" type="text" placeholder="Clinic workstation">
                </div>
            </div>

            <button id="request-btn" type="submit">Send one-time passcode</button>

            <p class="tagline" id="request-help">
                We’ll send a six-digit code that expires in five minutes. No passwords to memorize.
            </p>
        </form>

        <form id="verify-form" class="hidden" autocomplete="off">
            <div class="banner" id="otp-banner"></div>

            <label for="otp-code">Enter the 6-digit code</label>
            <input id="otp-code" name="code" type="text" inputmode="numeric" maxlength="6" placeholder="123456" required>

            <button id="verify-btn" type="submit">Verify &amp; continue</button>

            <div class="secondary-actions">
                <button id="resend-btn" type="button">Resend code</button>
                <button id="change-contact-btn" type="button">Use different contact</button>
            </div>

            <p class="tagline">
                Having trouble? Resend the code or try the other channel.
            </p>
        </form>
    </main>

    <script>
        const apiBase = '<?php echo e(rtrim(config('app.url'), '/')); ?>/api/v1';
        const requestForm = document.getElementById('request-form');
        const verifyForm = document.getElementById('verify-form');
        const messages = document.getElementById('messages');
        const requestButton = document.getElementById('request-btn');
        const verifyButton = document.getElementById('verify-btn');
        const resendButton = document.getElementById('resend-btn');
        const changeContactButton = document.getElementById('change-contact-btn');
        const identityInput = document.getElementById('identity');
        const channelSelect = document.getElementById('channel');
        const deviceInput = document.getElementById('device_name');
        const otpInput = document.getElementById('otp-code');
        const banner = document.getElementById('otp-banner');

        let currentIdentity = '';
        let currentChannel = 'email';

        function showMessage(type, text) {
            messages.innerHTML = '';
            if (!text) return;
            const div = document.createElement('div');
            div.className = `alert ${type}`;
            div.textContent = text;
            messages.appendChild(div);
        }

        function toggleForms(showVerify) {
            requestForm.classList.toggle('hidden', showVerify);
            verifyForm.classList.toggle('hidden', !showVerify);
            if (showVerify) {
                otpInput.value = '';
                otpInput.focus();
            } else {
                identityInput.focus();
            }
        }

        async function requestOtp(event) {
            event.preventDefault();
            showMessage('', '');

            currentIdentity = identityInput.value.trim();
            currentChannel = channelSelect.value;

            if (!currentIdentity) {
                showMessage('error', 'Please enter an email or phone number.');
                return;
            }

            requestButton.disabled = true;
            requestButton.textContent = 'Sending…';

            try {
                const response = await fetch(`${apiBase}/auth/request-otp`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                    body: JSON.stringify({
                        identity: currentIdentity,
                        channel: currentChannel,
                        device_name: deviceInput.value || undefined
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (!response.ok) {
                    throw new Error(data.message || 'Unable to send OTP. Please try again.');
                }

                banner.innerHTML = `We sent a passcode to <strong>${currentIdentity}</strong>. Enter it below.`;
                showMessage('success', data.message || 'OTP sent successfully.');
                toggleForms(true);
            } catch (error) {
                showMessage('error', error.message);
            } finally {
                requestButton.disabled = false;
                requestButton.textContent = 'Send one-time passcode';
            }
        }

        async function verifyOtp(event) {
            event.preventDefault();
            showMessage('', '');

            const code = otpInput.value.trim();
            if (code.length < 4) {
                showMessage('error', 'Enter the six-digit code you received.');
                return;
            }

            verifyButton.disabled = true;
            verifyButton.textContent = 'Verifying…';

            try {
                const response = await fetch(`${apiBase}/auth/verify-otp`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                    body: JSON.stringify({
                        identity: currentIdentity,
                        channel: currentChannel,
                        code
                    })
                });

                const data = await response.json().catch(() => ({}));

                if (!response.ok) {
                    throw new Error(data.message || 'Verification failed. Check the code and try again.');
                }

                showMessage('success', 'OTP verified. Redirecting to dashboard…');
                setTimeout(() => {
                    window.location.href = '/dashboard';
                }, 800);
            } catch (error) {
                showMessage('error', error.message);
            } finally {
                verifyButton.disabled = false;
                verifyButton.textContent = 'Verify & continue';
            }
        }

        function resendOtp() {
            requestForm.dispatchEvent(new Event('submit'));
        }

        function changeContact() {
            showMessage('', '');
            toggleForms(false);
        }

        requestForm.addEventListener('submit', requestOtp);
        verifyForm.addEventListener('submit', verifyOtp);
        resendButton.addEventListener('click', resendOtp);
        changeContactButton.addEventListener('click', changeContact);
    </script>
</body>
</html>
<?php /**PATH /Users/seanb/Documents/Audical-Services/backend/resources/views/login.blade.php ENDPATH**/ ?>