<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\OtpCode;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Tests\TestCase;
use App\Services\Auth\OtpService;

class OtpTest extends TestCase
{
    use RefreshDatabase;

    public function test_can_request_otp_via_email()
    {
        Mail::fake();
        Config::set('auth.otp.delivery_mode', 'email');

        $response = $this->postJson('/api/v1/auth/request-otp', [
            'identity' => 'test@example.com',
        ]);

        $response->assertStatus(200)
            ->assertJson(['message' => 'OTP sent successfully.']);

        $this->assertDatabaseHas('otp_codes', [
            'identity' => 'test@example.com',
            'channel' => 'email',
        ]);
    }

    public function test_can_verify_otp()
    {
        Config::set('auth.otp.delivery_mode', 'log');
        
        // Generate an OTP first
        $service = app(OtpService::class);
        $otp = $service->generate('test@example.com');
        
        // We can't easily get the plain text code from the service since it's hashed in DB
        // But for 'log' mode in local environment/test, we might be able to predict it 
        // or we can mock the random_int function if we could, but here let's just 
        // manually create a record or capture the code return?
        // Wait, the service generate() method returns the OtpCode model, but NOT the plain text code if it was random.
        // Actually, looking at OtpService.php: 
        // $code = $this->generateCode(); ... $otp = OtpCode::create([...]); $this->deliver(...); return $otp;
        // The returned $otp does NOT contain the plain text code, only the hash.
        
        // However, we can use the "Fixed Code" feature for testing if creating a new one via service
        // OR we can manually insert a known code into the DB for verification test.
        
        $code = '123456';
        OtpCode::create([
            'identity' => 'test@example.com',
            'channel' => 'email',
            'code_hash' => Hash::make($code),
            'ip_address' => '127.0.0.1',
            'expires_at' => now()->addMinutes(5),
            'created_at' => now(),
        ]);

        $this->withoutExceptionHandling();

        $response = $this->postJson('/api/v1/auth/verify-otp', [
            'identity' => 'test@example.com',
            'code' => $code,
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure(['access_token', 'user']);
    }

    public function test_otp_expiry()
    {
        $code = '123456';
        OtpCode::create([
            'identity' => 'test@example.com',
            'channel' => 'email',
            'code_hash' => Hash::make($code),
            'ip_address' => '127.0.0.1',
            'expires_at' => now()->subMinute(), // Expired
            'created_at' => now()->subMinutes(10),
        ]);

        $response = $this->postJson('/api/v1/auth/verify-otp', [
            'identity' => 'test@example.com',
            'code' => $code,
        ]);

        $response->assertStatus(422) // Or whatever status code the exception handler returns
                 ->assertJson(['message' => 'OTP expired.']);
    }

    public function test_invalid_otp_code()
    {
        $code = '123456';
        OtpCode::create([
            'identity' => 'test@example.com',
            'channel' => 'email',
            'code_hash' => Hash::make($code),
            'ip_address' => '127.0.0.1',
            'expires_at' => now()->addMinutes(5),
            'created_at' => now(),
        ]);

        $response = $this->postJson('/api/v1/auth/verify-otp', [
            'identity' => 'test@example.com',
            'code' => '654321', // Wrong code
        ]);

        $response->assertStatus(422)
                 ->assertJson(['message' => 'Invalid code.']);
    }
}
